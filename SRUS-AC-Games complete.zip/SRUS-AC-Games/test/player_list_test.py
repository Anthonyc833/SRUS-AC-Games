import unittest

from app import player
from app.player import Player
from app.playerlist import PlayerList
from app.player_node import PlayerNode




class TestPlayerList(unittest.TestCase):

    def test_there_or_not(self):
        self.assertTrue(PlayerList().is_empty())

    def test_insert_tail(self):
      #arrange#
        plist = PlayerList()
        player1 = Player("01", "Mike")
        player2 = Player("02","raf")
      #act
        plist.insert_tail(player1)
        plist.insert_tail(player2)

        self.assertIs(plist._tail_player.player, player2)



    def test_removal(self):
        #arrange
        "prev should be none"
        plist = PlayerList()
        plist.insert_head(Player("01", "Anthony"))
        print(plist._head_player)
        plist.insert_head(Player("02","Xxx"))
        self.assertEqual(plist._head_player.player.get_uid(), "02")
        #act
        plist.delete_head()
        self.assertEqual(plist._head_player.player.get_uid(), "01")




    def test_tail_remove(self):
        # arrange
        plist = PlayerList()
        '''tailplayer next should be none'''
        plist.insert_head(Player("01","Anthony"))
        plist.insert_tail(Player("02", "Anthy"))
        self.assertEqual(plist._tail_player.player.get_uid(), "02")
        # act
        print(plist._head_player.player)
        print(plist._tail_player.player)
        plist.delete_tail()
        print(plist._head_player.player)
        print(plist._tail_player.player)
        self.assertEqual(plist._tail_player.player.get_uid(), "01")




    def test_removal_by_key(self):
        # arrange
        '''' finding the player by its key and deleteing the player'''
        plist = PlayerList()
        plist.insert_head(Player("01", "Anthony"))
        plist.insert_tail(Player("02", "xxx"))
        # act
        print(plist._head_player.player)
        print(plist._tail_player.player)
        plist.remove_key("01")

        print(plist._head_player.player)
        print(plist._tail_player.player)
        # assert
        self.assertEqual(plist._head_player.player.get_uid(), "02")


