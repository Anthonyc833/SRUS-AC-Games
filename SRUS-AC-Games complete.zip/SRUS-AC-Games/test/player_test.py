import unittest
from app.player import Player

a_uid = "321"
a_name = "Tony"

class TestPlayer(unittest.TestCase):
    def test_uidandstring (self):
        player = Player(a_uid, a_name)
        self.assertIn(a_uid, str(player))
        self.assertIn(a_name, str(player))





