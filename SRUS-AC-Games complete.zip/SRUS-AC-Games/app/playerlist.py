from app.player import Player
from app.player_node import PlayerNode


class PlayerList:
    def __init__(self):
        self._head_player = None
        self._tail_player = None

    def is_empty(self):
        return self._head_player is None


    def insert_head(self, player: Player):
        if self.is_empty():
            self._head_player = self._tail_player = PlayerNode(player)
        else:
            new_node = PlayerNode(player)
            self._head_player.prev = new_node
            new_node.next = self._head_player
            self._head_player = new_node

    def insert_tail(self, player: Player):
        if self.is_empty():
            self._tail_player = self._head_player = PlayerNode(player)
        else:
            new_tail = PlayerNode(player)
            self._tail_player.next = new_tail
            new_tail.prev = self._tail_player
            self._tail_player = new_tail

    def remove_key(self, key):
        if self._head_player.player.get_uid() == key:
            self.delete_head()
            self.is_empty()
        elif self._tail_player.player.get_uid() == key:
            self.delete_tail()
            self.is_empty()

    def delete_head(self):
        if self.is_empty():
            raise IndexError("Delete from empty list")
        if self._head_player is self._tail_player:
            self._head_player = self._tail_player = None
        else:
            self._head_player = self._head_player.next
            self._head_player.prev = None




    def delete_tail(self):
        if self.is_empty():
            raise IndexError("delete from empty list")
        if self._tail_player is self._head_player:
            self._tail_player = self._head_player = None
        else:
            self._tail_player = self._tail_player.prev
            self._tail_player.next = None

    def display(self):
        forward = True
        while forward == True:

            print(self._head_player)
            print(self._tail_player)




def main():
    plist = PlayerList()
    plist.display()


if __name__ == "__main__":
    main()
