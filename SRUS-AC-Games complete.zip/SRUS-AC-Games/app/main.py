class player:
    def __init__(self, UID, Playername):
        self.UID = UID
        self.Playername = Playername

    def __str__(self):
        self.Playername = "";